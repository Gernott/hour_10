CREATE TABLE tx_hour_domain_model_hour (
	title varchar(255) NOT NULL DEFAULT '',
	start datetime DEFAULT NULL
);
