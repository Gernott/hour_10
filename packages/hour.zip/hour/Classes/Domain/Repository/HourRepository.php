<?php

declare(strict_types=1);

namespace WEBprofil\Hour\Domain\Repository;


/**
 * This file is part of the "Hour" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * (c) 2022 
 */

/**
 * The repository for Hours
 */
class HourRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{
}
